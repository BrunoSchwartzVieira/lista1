
package exercicio2lista1b;
import java.util.Scanner;

public class Exercicio2lista1b {

    
    public static void main(String[] args) {
      Scanner scanner = new Scanner(System.in);

       
        System.out.println("Digite seu nome: ");
        String nome = scanner.nextLine();

      
        System.out.println("Olá, " + nome + "! Bem-vindo ao programa.");

        
        scanner.close();
    }
    
}
