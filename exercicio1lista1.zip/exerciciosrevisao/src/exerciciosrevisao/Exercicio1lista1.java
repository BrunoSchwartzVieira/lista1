
package exerciciosrevisao;


public class Exercicio1lista1 {

   
    public static void main(String[] args) {
       
        System.out.println("Olá, mundo!");
        
    }
    
}
