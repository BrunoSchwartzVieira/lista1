
package exercicio3lista1;

import java.util.Scanner;

public class Exercicio3lista1 {

    
    public static void main(String[] args) {
        
        String saudacao = "Olá,";
        String mundo = " mundo!";
        
        String mensagemCompleta = saudacao + mundo;
        System.out.println(mensagemCompleta);
        
    }
    
}
